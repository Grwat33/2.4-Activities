# Info in Dictionaries

## Instructions

* Create a dictionary to store the following:

  * Your name
  * Your age
  * A list of a few of your hobbies
  * A dictionary of a few times you wake up during the week

* Print out your name, how many hobbies you have and a time you get up during the week.
